# Latest Source Boundary

현재 패키지가 직접 확인한 HyunseoRPG 전체 소스는 2026-08-04 접근 가능한 ZIP 스냅샷이다.

그 이후 농사/양조 완료 소스는 이 작업 환경에서 열 수 없으므로 다음을 의도적으로 하지 않았다.

- 최신 `FarmingBridge` 클래스명을 추측하여 import
- 최신 EffectEngine 클래스명을 추측하여 import
- 최신 abundance/delivery 구현을 탐험에 연결
- items.yml에 신규 탐험 아이템 추가
- 상위 `HyunseoRPGPlugin` 파일 직접 수정

대신 `ExplorationPorts`와 `ExplorationModule`을 독립 경계로 제공한다.

최신 데스크톱 소스에서 바뀐 API가 있더라도 core 수정이 아니라 Adapter/Bootstrap 수정으로 끝내는 것이 목표다.
