# Persistence Contract

## 영속성 우선순위

`StructureRecord`가 권위 데이터다. Runtime은 언제든 폐기/재구성 가능한 임시 상태다.

## State transition

```text
VANILLA       terminal
UNDISCOVERED -> ACTIVE
ACTIVE       -> CLEARED
ACTIVE       -> ABANDONED
CLEARED       terminal
ABANDONED     terminal
```

다른 전이는 금지한다.

## 저장 실패

- 최초 record 저장 실패: 이벤트 활성화 금지
- ACTIVE 전환 저장 실패: component 실행 금지
- CLEARED 저장 실패: runtime 유지, 완료 실패로 보고
- ABANDONED 저장 실패: runtime 유지, 재시도 가능

## Reload

Registry reload는 앞으로의 미발견 구조물 정의를 변경할 수 있지만 **기존 record의 selected/variant/state를 다시 계산하지 않는다.**
