# Exploration Ports Contract

탐험 Core와 외부 HyunseoRPG 모듈 사이의 유일한 권장 경계다.

## MobSpawnPort

```java
Collection<UUID> spawn(String mobId, Location location, int count, Map<String,Object> options)
```

- `vanilla:<entity>`는 Bukkit 기본 adapter가 처리 가능
- HyunseoRPG custom mob은 `MobService` adapter가 처리
- 실패 시 빈 collection
- objective component가 빈 결과를 받으면 자동 클리어 모드에 들어가지 않음

## DisplayPort

BlockDisplay 등 이벤트 임시 표현을 생성하고 UUID를 반환한다. 반환 UUID는 runtime tracker가 Cleanup한다.

## InteractionPort

Interaction entity를 생성한다. 실제 클릭 라우팅은 후속 Component/Listener가 연결한다.

## WorldMutationPort

임시 블록 변경 후 **원상 복구 Runnable**을 반환한다. 영구 외형 Variant에는 사용하지 않는다.

## TeleportPort

이벤트 내부 단계 전환용 이동. `ForcedRelocationComponent`는 호출 전에 해당 플레이어에 teleport exemption을 기록한다.

## RewardPort

```java
boolean grant(Player player, String rewardId, int amount, Location fallback, Map<String,Object> options)
```

현재 개별 지급 adapter는 2026-08-04 소스의 `RPGItemService#create` + `InventoryDeliveryService#giveOrDrop`에 맞춘다.

주의: 다인 참여 보상의 완전한 원자성/재시도 idempotency는 최신 보상 구조 확인 후 강화해야 한다. 기본 템플릿에는 reward component를 활성화하지 않는다.

## PuzzlePort

구조물별 퍼즐 엔진을 core 안에 하드코딩하지 않는다. 시작 시 Cleanup Runnable을 반환한다.

## 금지 의존성

Core에서 다음을 직접 import하지 않는다.

- farming implementation
- alchemy/effect implementation
- territory implementation
- future structure-specific reward implementation

필요 시 Adapter만 추가한다.
