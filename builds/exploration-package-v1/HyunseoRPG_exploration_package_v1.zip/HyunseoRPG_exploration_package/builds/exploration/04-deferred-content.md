# 04 Deferred Content

현재 패키지에서 의도적으로 **구현하지 않은 확정/후속 콘텐츠**다.

- 사막 피라미드 puzzle chest/timed bomb/quiz variants
- 시련의 회당 key match
- 보루 잔해 greed counter
- 바다 신전 seal 3개 + 최종 전투 단계
- 엔드 도시 low-gravity environment
- structure exterior variants
- 월드 elite director
- 탐사 렌즈 실제 structure lookup bridge
- 영지 시스템
- 농사 납품 -> 영지 현장 이식
- 최신 EffectEngine 연결
- 커스텀 몹별 실제 스킬/수치
- 실제 reward pool

이 항목을 core에 임의 구현하지 않은 이유는 최신 설계가 **공통 엔진 선행 후 콘텐츠를 하나씩 조합**하도록 명시하기 때문이다.
