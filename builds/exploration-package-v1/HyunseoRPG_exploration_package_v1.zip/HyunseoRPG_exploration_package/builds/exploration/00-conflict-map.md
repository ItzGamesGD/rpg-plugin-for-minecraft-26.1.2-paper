# 00 Conflict Map

## 낮은 위험

- 새 `com.hyunseo.hyunseorpg.exploration` 패키지: 기존 이름 충돌 없음
- `exploration/structures.yml`: 독립 resource 경로
- 월드별 `plugins/HyunseoRPG/exploration/structures/*.yml`: 농사 저장과 경로 분리

## 중간 위험

### ChunkLoadEvent
기존 다른 listener와 동시에 실행될 수 있다. 탐험 listener는 구조물을 관측/저장할 뿐 블록을 변경하지 않으므로 기본 충돌 가능성은 낮다.

### PlayerMoveEvent
탐험 listener는 ACTIVE runtime 경계만 검사한다. 매 이동에서 월드 전체 scan을 하지 않는다. 실제 성능은 서버에서 측정 필요.

### Mob spawn/reward
최신 소스에서 서비스 signature가 바뀌었을 수 있다. Adapter 하나만 재작성하도록 격리했다.

## 높은 위험/후속 검증

### Paper generated structure API
빌드 대상 26.1.2에는 필요한 조회 API가 존재하지만, 장기 API 변화 가능성이 있다. Provider 하나에 reflection 격리했다.

### Multi-player reward retry
개별 item delivery는 완전한 다인 atomic transaction을 제공하지 않는다. reward component는 기본 config에서 미사용하며 최신 `PendingRewardService`/보상 정책 확인 후 idempotency를 추가한다.

### ACTIVE recovery semantics
서버 재시작 후 persistent ACTIVE record는 runtime 객체를 잃는다. 현재는 다음 접근 시 runtime/component를 재구성한다. 복잡한 퍼즐에서 중간 진행을 저장해야 하는 경우 activationMetadata 확장이 필요하다.

## 명시적으로 건드리지 않은 영역

- farming
- alchemy/effects
- territory
- items.yml
- mobs.yml
- plugin.yml command tree
- main class
