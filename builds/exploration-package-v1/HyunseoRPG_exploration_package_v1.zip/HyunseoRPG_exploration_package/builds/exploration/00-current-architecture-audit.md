# 00 Current Architecture Audit

대상: 현재 접근 가능한 `hyunseorpg-paper-spigot-rpg-hyunseorpg-1(4).zip`.

## 확인된 기존 패턴

### Bootstrap
- `HyunseoRPGPlugin`이 service/registry를 직접 소유하고 `onEnable`에서 생성한다.
- `onDisable`에서 서비스별 stop/shutdown/flush를 호출한다.
- `RPGReloadService`가 이름별 reload callback을 등록한다.

### Registry
확인된 예:
- `RPGItemRegistry`
- `MobRegistry`
- `MonsterSpawnRegistry`
- `CraftingRecipeRegistry`
- `CropRegistry`
- `EnchantRegistry`
- `EquipmentRegistry`

탐험은 기존 Registry를 합치지 않고 `ExplorationRegistry`를 독립 생성하되, 외부 item/mob lookup은 adapter로 위임한다.

### World persistence
농사에 `CropIndex`, `CropStorage`, `YamlChunkCropStorage` 패턴이 존재한다.

탐험은 이 철학을 재사용하여:
- `StructureIndex`
- `StructureStorage`
- `YamlStructureStorage`
- `StructureRepository`
로 구성했다.

### Mob
2026-08-04 스냅샷에서 `MobService#spawnCustomMob(Location,String,Integer,String)`을 확인했다. `ExistingHyunseoRpgAdapters.mobPort`가 이 경로만 참조한다.

### Item/reward
- `RPGItemService#create(String,int)`
- `InventoryDeliveryService#giveOrDrop(Player,Location,ItemStack)`
를 확인했다.

탐험 reward adapter는 이 공개 경로만 참조한다.

### Scheduler
기존 모듈들은 start/stop life-cycle을 가진다. 탐험 역시 `ExplorationModule.start/stop`으로 감싼다.

## 확인하지 못한 최신 영역

- 농사 완료 후 최종 API
- 양조/EffectEngine 최종 클래스명
- 최신 items registry 변경
- 최신 main bootstrap 변경

따라서 위 네 영역은 직접 의존하지 않는다.
