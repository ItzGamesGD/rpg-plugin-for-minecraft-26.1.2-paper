# 00 Implementation Plan

## 현재 패키지에서 선구현

### P0 Architecture
- source audit
- package/port boundary

### P1 E1 Detection/Registry
- `ExplorationRegistry`
- `StructureCandidateProvider`
- `ReflectivePaperStructureCandidateProvider`
- `DeterministicStructureSelector`
- `StructureDetectionService`

### P2 E2 Persistence
- `StructureRecord`
- `StructureStorage`
- `YamlStructureStorage`
- `StructureIndex`
- `StructureRepository`

### P3 E3 Activation
- `ExplorationHeartbeatTask`
- `ExplorationRuntime`
- `ExplorationRuntimeManager`

### P4 E4 Completion/Abandon/Cleanup
- `RuntimeObjectTracker`
- `TeleportExemptionService`
- movement/teleport listener

### P5 E5 Component engine
- registry + context + reusable components

### P6 E6 prototype skeleton
- disabled `swamp_hut/elite_witch_prototype`
- vanilla witch objective only
- no reward

## 데스크톱 최신 소스 이식 후

### P7 Bootstrap
- `HyunseoRPGPlugin` field 추가
- Mob/Reward adapter 조립
- `explorationModule.start()`
- `onDisable -> explorationModule.stop()`
- reload callback 추가

### P8 Paper live prototype
- structure detection key 확인
- generated bounds 확인
- restart/reload reroll 방지
- objective completion
- physical escape vs teleport
- cleanup

### P9 first content
문서 순서대로 단순 구조물부터 시작한다. 숫자/보상/몹 구성은 별도 콘텐츠 확정 후 넣는다.
