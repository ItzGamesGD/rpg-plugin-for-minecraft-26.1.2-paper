# 02 Integration Map

## 현재 확인 소스 기준

```text
HyunseoRPGPlugin
  ├─ MobService --------------------┐
  ├─ RPGItemService ---------------┼─ ExistingHyunseoRpgAdapters
  └─ InventoryDeliveryService -----┘
                                    ↓
                              ExplorationPorts
                                    ↓
                              ExplorationModule
```

## Main class 최소 변경안

상위 소스에는 아래 **개념적 변경만** 필요하다.

1. field: `ExplorationModule explorationModule`
2. MobService/ItemService/DeliveryService가 초기화된 뒤 ports 조립
3. `explorationModule.start()`
4. `onDisable`에서 `explorationModule.stop()`
5. `RPGReloadService`에 `exploration -> explorationModule.reload()` 등록

정확한 삽입 줄 번호는 최신 데스크톱 소스에서 다시 잡는다.

## 권장 ports 조립

- base: `BukkitExplorationPorts.safeDefaults(plugin)`
- mob: `ExistingHyunseoRpgAdapters.mobPort(mobService)`
- reward: 최신 보상 원자성 확인 후 연결

현재 `ExplorationPorts` record는 개별 port를 명시적으로 전달하므로, 최신 소스에서 factory helper를 추가해도 core에는 영향이 없다.
