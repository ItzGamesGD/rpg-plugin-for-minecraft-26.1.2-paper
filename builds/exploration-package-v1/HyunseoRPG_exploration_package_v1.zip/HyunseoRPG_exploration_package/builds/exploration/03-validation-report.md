# 03 Validation Report

## 성공

- source tree 생성
- core Java 직접 컴파일
- core smoke test (`CORE_SMOKE_OK`)
- production Java 전체 API-stub compile (`FULL_STUB_COMPILE_OK`)
- test Java 전체 API/JUnit-stub compile (`TEST_SOURCE_STUB_COMPILE_OK`)
- YAML parse 및 안전 기본값 검사 (`CONFIG_SAFETY_OK`, 9 structure definitions)
- farming/alchemy/effects/territory 직접 import 방지 검사 (`DEPENDENCY_FIREWALL_OK`)
- 안전 기본값: module disabled, selection chance zero
- 공식 Paper Javadoc과 구조물 조회 API 대조

## 환경 때문에 미실행

`./gradlew test`를 시도했지만 Gradle wrapper가 필요한 Gradle 배포본을 로컬에서 찾지 못해 외부 다운로드를 시도했고, 실행 환경의 DNS/인터넷 제한으로 실패했다.

또한 현재 런타임 JDK는 21이고 대상 프로젝트는 Java 25다.

따라서 **전체 프로젝트 Gradle 성공을 주장하지 않는다.**

## 데스크톱 필수 검증

1. JDK 25
2. `./gradlew clean test`
3. Paper 26.1.2 서버 부팅
4. `enabled: true`, prototype만 수동 시험
5. 신규 청크 swamp hut 감지 여부
6. 동일 구조물 reload/restart 후 UUID/variant/state 동일
7. 접근 전 Entity/Display 없음
8. 접근 후 1회 activation
9. objective 제거 시 CLEARED
10. 물리 이탈 시 grace 이후 ABANDONED
11. 시스템 teleport로 ABANDONED 되지 않음
12. completion/abandon 후 runtime object 0
13. profiler로 movement/heartbeat 비용 측정
