# 01 Core Implementation Report

## 구현 완료

- persistent lifecycle model
- deterministic ID/selection/variant
- chunk spatial index
- atomic YAML storage
- chunk structure observation adapter
- approach activation
- server restart ACTIVE re-entry path
- physical abandon grace
- teleport exemption
- centralized cleanup
- reusable event component registry
- minimal vanilla mob objective prototype

## 정적 검증 중 발견/수정한 결함

`StructureRecord`가 VANILLA record의 빈 `variantId`를 normalize하면서 예외가 나는 문제를 발견했다. 빈 variant를 정상 허용하고 non-RPG record에는 non-empty variant를 금지하도록 수정했다.

## 검증 완료

Bukkit-free core를 JDK 21에서 직접 컴파일했다. 프로젝트 실제 target은 Java 25이나 현재 런타임에는 JDK 21만 존재한다. 사용한 언어 기능은 Java 21에서도 컴파일 가능한 범위다.

Smoke test 검증:
- stable ID 재현성
- deterministic variant
- VANILLA terminal
- UNDISCOVERED -> ACTIVE -> CLEARED
- completedAt 설정
- multi-chunk structure indexing

결과: `CORE_SMOKE_OK`.
