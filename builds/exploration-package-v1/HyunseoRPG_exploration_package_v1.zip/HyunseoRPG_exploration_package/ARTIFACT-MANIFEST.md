# Artifact Manifest

- production Java: 40 files
- test Java: 4 files
- resources: 2 files
- total files before checksum manifest: 73

## Validation labels

- CORE_SMOKE_OK
- FULL_STUB_COMPILE_OK
- TEST_SOURCE_STUB_COMPILE_OK
- CONFIG_SAFETY_OK
- DEPENDENCY_FIREWALL_OK
- FULL_GRADLE_TEST_BLOCKED_BY_ENVIRONMENT

See `builds/exploration/03-validation-report.md`.
