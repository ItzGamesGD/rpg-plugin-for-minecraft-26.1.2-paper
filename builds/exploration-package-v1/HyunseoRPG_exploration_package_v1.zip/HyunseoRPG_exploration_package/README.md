# HyunseoRPG Exploration Package

기준 설계: `HyunseoRPG 3차 탐험 · 영지 통합 확정안` (2026-08-13)
기준 소스: 현재 열람 가능한 `hyunseorpg-paper-spigot-rpg-hyunseorpg-1(4).zip` 스냅샷

이 패키지는 탐험 아이디어 문서가 아니라 **독립 삽입 가능한 탐험 엔진 기반 구현물**이다.

## 포함 범위

- E1 구조물 감지/Registry 기반
- E2 영속 `StructureRecord` + 월드별 YAML 저장
- E3 접근 기반 런타임 활성화
- E4 `CLEARED / ABANDONED` + Cleanup + 시스템 텔레포트 이탈 면제
- E5 재사용 Event Component API
- E6용 최소 `swamp_hut` 전투 프로토타입 템플릿
- 기존 `MobService`, `RPGItemService`, `InventoryDeliveryService` Adapter
- 최신 농사/양조 구현과 직접 결합하지 않는 Port 경계
- 단위 테스트 및 데이터 테스트
- 실제 상위 소스 이식 명세와 후속 분할 프롬프트

## 설치 안전 기본값

`exploration/structures.yml`은 최상위 `enabled: false`이며 모든 RPG 선정 확률은 `0.0`이다. 따라서 단순 파일 삽입만으로 월드 구조물이 변경되거나 이벤트가 활성화되지 않는다.

## 핵심 의존 방향

```text
Paper structure observation
        ↓
StructureCandidateProvider
        ↓
StructureDetectionService
        ↓
DeterministicStructureSelector
        ↓
StructureRepository + StructureIndex
        ↓
ExplorationRuntimeManager
        ↓
ExplorationComponentRegistry
        ↓
ExplorationPorts
        ↓
HyunseoRPG mob/item/reward or future modules
```

탐험 Core는 농사/양조를 import하지 않는다.

## 검증 상태

- Bukkit-free Core 직접 `javac` 컴파일 및 smoke test 통과
- Paper 26.1.2 API의 `World#getStructures(int,int)`, `GeneratedStructure#getStructure()`, `GeneratedStructure#getBoundingBox()` 존재를 공식 Javadoc과 대조
- 전체 Gradle test는 현재 실행 환경에 Gradle 배포본/Paper API 캐시가 없고 외부 다운로드가 차단되어 실행하지 못함
- 최종 데스크톱 이식 시 `./gradlew test` 및 실제 Paper 서버 프로토타입 검증 필요

자세한 내용은 `builds/exploration/` 문서를 따른다.
