# 탐험 실구현 명세

## 1. 설계 불변조건

1. RPG 대상 여부는 최초 1회 고정된다.
2. Variant 역시 최초 1회 고정된다.
3. 재부팅, 리로드, 청크 언로드/로드로 재추첨하지 않는다.
4. 구조물 상태는 월드 공용이다.
5. 기본 이벤트는 1회성이며 `CLEARED` 또는 `ABANDONED` 이후 재실행하지 않는다.
6. 런타임 객체는 플레이어 접근 시에만 생성한다.
7. 정상적인 물리 이탈만 `ABANDONED` 후보가 된다.
8. 시스템 텔레포트는 이탈 판정에서 면제할 수 있어야 한다.
9. 구조물별 거대한 Handler보다 작은 Component 조합을 우선한다.
10. 외형 Variant는 Event Engine 안정화 뒤에 추가한다.

## 2. Persistent model

```text
StructureRecord
  structureId
  worldId
  structureType
  minecraftKey
  anchor
  bounds
  rpgSelected
  variantId
  state: VANILLA | UNDISCOVERED | ACTIVE | CLEARED | ABANDONED
  activationMetadata
  rewardClaimed
  createdAt
  completedAt
  dataVersion
```

`Location`, Entity, Display, Interaction 같은 Bukkit 런타임 객체는 저장하지 않는다.

## 3. 선택 안정성

구조물 UUID는 `world UUID + vanilla structure key + bounding box`로 결정적으로 생성한다.

RPG 선정과 Variant 선택도 구조물 UUID 기반 SHA-256 deterministic roll을 사용한다. 따라서 감지 직후 서버가 비정상 종료되어 저장 전에 같은 구조물이 다시 관측되어도 결과 자체가 달라지지 않는다.

## 4. 저장

현재 구현은 월드별 YAML:

```text
plugins/HyunseoRPG/exploration/structures/<world-uuid>.yml
```

저장은 temp 파일 작성 후 atomic move를 우선 사용한다. 저장 인터페이스는 `StructureStorage`로 격리되어 향후 SQLite/region 저장으로 교체 가능하다.

## 5. Detection

- 청크 로드 시 해당 청크와 교차하는 생성 구조물을 조회한다.
- Paper 구조 API 접근은 `StructureCandidateProvider` 뒤에 격리한다.
- 구조물 key가 현재 Registry에 등록되지 않았으면 무시한다.
- 이미 `structureId`가 존재하면 아무 것도 하지 않는다.
- 미선정 구조물도 `VANILLA` record로 저장하여 재추첨을 막는다.

## 6. Runtime

`ExplorationHeartbeatTask` 하나만 사용한다. 구조물마다 반복 task를 만들지 않는다.

접근:
- `UNDISCOVERED` + trigger radius 진입 -> `ACTIVE` 저장 -> runtime 생성 -> ACTIVATE component 실행
- 이미 `ACTIVE`인데 서버 재시작 등으로 runtime이 없다면 접근 시 runtime을 복원하고 ACTIVATE phase를 재구성한다.

종료:
- 명시적 completion 또는 objective entity 전멸 -> CLEAR phase -> `CLEARED`
- 실제 물리 경계 이탈 + grace -> `ABANDONED`
- 어느 종료든 모든 임시 객체 Cleanup

## 7. Component

현재 구현:

- `scripted_spawn`
- `display_target`
- `interaction_target`
- `temporary_seal`
- `forced_relocation`
- `reward_drop`
- `puzzle`

각 Component는 `ExplorationPorts`만 통해 외부 기능을 호출한다.

## 8. 안전 정책

- 미확정 수치 전부 YAML/`BALANCE_PENDING`
- 기본 config 전체 비활성
- reward/puzzle adapter가 없으면 silent 성공으로 처리하지 않는다
- 월드/Entity 조작은 main thread에서만 호출하는 전제
- farming/alchemy 직접 import 금지
- 구조물 외형 블록 덮어쓰기 구현은 현재 범위 제외
