# 탐험 2단계 - E2 Persistence 검증

StructureStorage/Repository/Index/YAML 저장을 검증하라.

필수:
- 월드별 load/save
- corrupt record skip + log
- atomic replace
- multi-chunk bounds index
- restart/reload 후 state 유지
- VANILLA/CLEARED/ABANDONED terminal 유지
- 데이터 삭제/재추첨 금지
