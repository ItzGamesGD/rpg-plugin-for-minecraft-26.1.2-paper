# 탐험 6단계 - E6 첫 구조물 프로토타입

가장 단순한 전투형 구조물 하나로 전체 생명주기를 검증하라. 현재 패키지에는 swamp_hut 템플릿이 있으나 최종 대상은 최신 설계 판단에 따라 마녀 오두막 또는 전초기지 중 하나를 선택할 수 있다.

프로토타입에서는 복잡한 보상/외형 변경을 추가하지 않는다.

확인:
- 최초 구조물 고정
- 접근 activation
- 임시 mob spawn
- objective 종료
- CLEARED 저장
- 재방문 미실행
- 도주 ABANDONED
- reload/restart
- cleanup
