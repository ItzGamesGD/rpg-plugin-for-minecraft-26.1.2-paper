# 탐험 3단계 - E3 Runtime Activation

접근 전 runtime object가 존재하지 않고 trigger radius 진입 시에만 ACTIVE가 되도록 검증하라.

필수:
- persistent ACTIVE 저장이 component 실행보다 선행
- 동일 runtime 중복 생성 금지
- 다른 플레이어 접근은 world-shared event 참가자로 합류
- 구조물별 repeating task 생성 금지
- heartbeat 비용 측정
