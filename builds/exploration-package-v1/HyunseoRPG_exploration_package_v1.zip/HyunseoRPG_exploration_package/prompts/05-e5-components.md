# 탐험 5단계 - E5 Common Components

현재 component registry를 실제 최신 서비스와 연결하라.

대상:
- scripted_spawn
- display_target
- interaction_target
- temporary_seal
- forced_relocation
- reward_drop
- puzzle

원칙:
- structure별 거대 handler 금지
- 공통 component로 표현 불가할 때만 새 component 추가
- 모든 runtime object는 tracker에 등록
- 미구현 external 기능은 adapter/port에서 fail-closed
