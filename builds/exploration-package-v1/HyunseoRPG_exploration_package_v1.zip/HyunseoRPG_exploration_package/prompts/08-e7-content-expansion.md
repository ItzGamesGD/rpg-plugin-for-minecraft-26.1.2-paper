# 탐험 8단계 - E7 구조물 콘텐츠 확장

엔진과 첫 prototype이 통과한 뒤에만 시작한다.

최신 확정안의 난이도 순서를 존중해 구조물을 하나씩 추가한다. 각 구조물은 기존 Component 조합을 먼저 시도하고, 부족할 때만 작은 신규 Component를 만든다.

각 구조물마다:
- trigger
- components
- clear condition
- abandon behavior
- cleanup
- reward hook
- server cost
를 문서화한다.

외형 Variant는 이 단계의 선행조건이 아니다.
