# 탐험 4단계 - E4 End/Cleanup

CLEARED/ABANDONED와 cleanup을 검증하라.

필수:
- 정상 물리 이동으로 abandon radius 이탈
- grace 적용
- 순간 경계 이탈 후 복귀 시 취소
- PlayerTeleportEvent 직접 원인으로 abandon 금지
- 시스템 forced relocation exemption
- 종료 후 Entity/Display/temporary block 전량 정리
- terminal event 재활성화 금지
