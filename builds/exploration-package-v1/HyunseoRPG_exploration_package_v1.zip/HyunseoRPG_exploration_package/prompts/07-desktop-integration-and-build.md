# 탐험 7단계 - 최신 소스 통합/빌드

이 exploration package를 최신 HyunseoRPG 소스에 이식하라.

순서:
1. latest-source recheck 문서 작성
2. package source/resource 복사
3. ExistingHyunseoRpgAdapters signature만 최신화
4. HyunseoRPGPlugin 최소 bootstrap 추가
5. reload callback 추가
6. JDK 25 / project target 확인
7. ./gradlew clean test
8. 실패 시 exploration 관련 오류와 기존 오류 분리
9. Paper 개발 서버 부팅
10. prototype lifecycle 테스트

금지:
- 전체 main class 리팩터링
- farming/alchemy 코드 수정
- items.yml/mobs.yml 임의 콘텐츠 추가
- BALANCE_PENDING 수치 확정

산출:
- builds/exploration/07-desktop-integration.md
- builds/exploration/07-test-report.md
