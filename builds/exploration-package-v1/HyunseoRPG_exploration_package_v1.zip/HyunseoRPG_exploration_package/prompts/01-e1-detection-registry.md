# 탐험 1단계 - E1 Detection/Registry 검증

패키지의 ExplorationRegistry, StructureCandidateProvider, StructureDetectionService, DeterministicStructureSelector를 최신 소스에 이식/검증하라.

완료 조건:
- 구조물 관측 가능
- 미등록 structure key 무시
- 동일 구조물 stable UUID 동일
- VANILLA 선정도 영구 record 저장
- RPG 선정과 variant 재시작 후 불변
- 운영 기본 selection chance는 0 또는 disabled
