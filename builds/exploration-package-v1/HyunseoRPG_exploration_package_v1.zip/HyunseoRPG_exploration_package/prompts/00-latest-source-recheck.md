# 탐험 0단계 - 최신 소스 재확인

현재 데스크톱 최신 HyunseoRPG 소스와 이 exploration package를 비교하라.

목표:
- package core를 재작성하지 않는다.
- 2026-08-04 이후 바뀐 API만 찾는다.

반드시 확인:
1. main bootstrap
2. MobService spawn API
3. RPGItemService item create API
4. InventoryDelivery/PendingReward API
5. reload framework
6. command framework
7. Paper target version/JDK
8. 이미 exploration/territory 유사 코드가 생겼는지

산출:
- builds/exploration/latest-source-diff.md
- 수정이 필요한 Adapter/Bootstrap 목록

금지:
- farming/alchemy internals를 exploration core에 직접 import
- 기존 StructureRecord/selector/state machine을 이유 없이 재설계
