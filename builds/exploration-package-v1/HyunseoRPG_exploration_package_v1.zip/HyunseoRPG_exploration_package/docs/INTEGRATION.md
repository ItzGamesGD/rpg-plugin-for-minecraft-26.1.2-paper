# Desktop Integration

이 문서는 **최신 전체 소스가 다시 열리는 시점**에 사용한다.

## 1. 복사

`src/main/java/com/hyunseo/hyunseorpg/exploration/` 전체를 동일 경로로 복사한다.

`src/main/resources/exploration/structures.yml`을 resource에 추가한다.

## 2. 기존 서비스 확인

먼저 실제 signature를 확인한다.

- `MobService#spawnCustomMob`
- `RPGItemService#create`
- `InventoryDeliveryService#giveOrDrop`
- 최신 reward/pending delivery API
- 최신 reload service

불일치 시 `ExistingHyunseoRpgAdapters`만 수정한다.

## 3. Main bootstrap

최신 소스에 `ExplorationModule` field를 추가한다.

모든 필요한 기존 서비스가 생성된 뒤 module을 조립한다. core 클래스 생성자를 직접 여기저기 호출하지 말고 `ExplorationModule` 한 객체만 소유한다.

## 4. Start order

권장:
- existing registries/services load
- exploration module construct
- exploration module start
- 나머지 repeating service start

실제 최적 위치는 최신 main source의 등록 순서를 보고 정한다.

## 5. Disable

플레이어 데이터 repository를 닫기 전에 exploration stop/flush가 실행되도록 한다.

## 6. Reload

`explorationModule.reload()`은 **정의만 reload**한다. 기존 StructureRecord를 삭제하거나 reroll하지 않는다.

## 7. 최초 테스트

처음에는:

```yaml
enabled: true
swamp_hut.enabled: true
swamp_hut.selection-chance: 1.0
```

처럼 개발 월드에서만 prototype을 강제로 선택해 전체 lifecycle을 검증한다. 운영 월드에서 바로 켜지 않는다.
