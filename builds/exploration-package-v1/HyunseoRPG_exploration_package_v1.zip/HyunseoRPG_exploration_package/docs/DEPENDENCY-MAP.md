# Dependency Map

```text
exploration.model           <- no Bukkit runtime object retention
exploration.registry        <- YAML definitions
exploration.persistence     <- model
exploration.detection       <- registry + persistence + Paper adapter
exploration.runtime         <- registry + persistence + components + ports
exploration.component       <- runtime context + ports
exploration.integration     <- external HyunseoRPG boundary
exploration.listener        <- runtime/detection only
ExplorationModule           <- composition root
```

금지하는 역방향:
- farming -> exploration core 강제 의존
- exploration core -> farming implementation
- exploration core -> alchemy implementation
- component -> HyunseoRPGPlugin global singleton

외부 모듈 호출은 `ExplorationPorts`로만 넘긴다.
