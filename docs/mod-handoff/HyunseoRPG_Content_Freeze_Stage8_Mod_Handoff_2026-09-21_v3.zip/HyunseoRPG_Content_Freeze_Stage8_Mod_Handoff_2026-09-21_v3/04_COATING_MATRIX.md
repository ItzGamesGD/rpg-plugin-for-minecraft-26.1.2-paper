# 4. Armor Coating Matrix

정확한 수치, 쿨다운, proc chance는 명시된 경우 외 BALANCE-DEFERRED.

## Copper / 구리
Helmet [LOCKED]
- 같은 대상을 공격할 때 전하 누적.
- 3중첩 도달 시 번개 피해 발생 후 초기화.

Chestplate [LOCKED]
- 전투 중 받은/축적된 피해를 전하처럼 저장.
- 이후 근접/원거리 공격 시 대규모 번개 공격으로 방출.

Leggings [LOCKED]
- 피격 시 전하 1 획득.
- 최대 안정 중첩 5.
- 각 중첩당 이동속도 +5%, 복리 금지.
- 5 이후 추가 전하가 들어오면 즉시 초기화하고 주변 전기 피해.

Boots [LOCKED]
- 피격 시 50% 확률로 해당 피해 10% 감소.
- 신속 II 2초.
- 약 5초 cooldown.

## Quartz / 석영
Helmet [LOCKED]
- 상시 critical.
- 40% 확률로 critical damage +20%.

Chestplate [LOCKED]
- 근접 피격 시 공격자에게 받은 피해의 20% 반사.

Leggings [LOCKED]
- 원거리 투사체 피격 시 일정 확률로 피해 무효/대폭 감소.
- 가능하면 투사체를 공격자 방향으로 굴절/반사.

Boots [LOCKED]
- 점프 후 착지 시 짧은 정밀 상태.
- 첫 공격 critical damage 추가 강화.

## Amethyst / 자수정
Helmet [LOCKED]
- 반경 10블록.
- Warden/Sculk가 감지 가능한 vibration/game event 발생 시
  이벤트 발생 위치에서 착용자 방향으로 vanilla VIBRATION 효과.
- 착용자에게만 보이도록 표현.
- Sculk 계열 감지음 재생.

Chestplate [LOCKED]
- 피격 시 공격자 방향으로 즉시 자수정 laser beam.
- 원거리 피해 + knockback.

Leggings [LOCKED]
- 모든 원거리 피격 시 공격자 방향으로 공명파.
- Warden Sonic Boom 계열 연출 사용 가능.

Boots [LOCKED]
- 일정 높이 이상 착지 시 공명 충격파.
- 주변 적 밀쳐냄.

## Lapis Lazuli / 청금석
Helmet [LOCKED]
- XP 획득 +30%.
- 마법부여/스킬 cooldown 15% 감소.

Chestplate [LOCKED]
- 장착 enchantment 기능 보조.
- enchant별 세부 지원표는 후속 정의.

Leggings [LOCKED]
- 달리는 동안 체력이 부족하면 XP를 소비하여 체력 회복.
- 회복량은 추후 높은 수준까지 허용 가능.

Boots [LOCKED]
- 낙하 피해 일부를 XP 소비로 대체.
- XP가 없으면 정상 낙하 피해.

## Emerald / 에메랄드
Helmet [LOCKED]
- Mob 처치 시 drop item 양 증가.
- 광석 채굴 시 Fortune III 상당 효과 상시 적용.

Chestplate [LOCKED]
- 치명적 피해 시 체력 1로 생존.
- 즉시 강력한 absorption/protection.
- cooldown 약 10분.

Leggings [LOCKED]
- Hero of the Village 강화.
- 향후 village 콘텐츠 효과 강화.

Boots [LOCKED]
- 새로운 chunk를 처음 밟을 때 낮은 확률로 행운 stack 획득.
- 자연 생성 loot chest / mob 처치 / ore 채굴에서 소비.
- stack 수에 따라 추가 reward roll.

## Gold / 금
Helmet [LOCKED]
- Piglin 및 villager 계열과 거래 UI/거래 상호작용 확장.

Chestplate [LOCKED]
- 근접 피격 시 공격자에게 약 1.5초간 Slowness V.

Leggings [LOCKED]
- 이동속도 +15%.
- 공격속도 +10%.

Boots [LOCKED]
- 블록 기반 이동 감속 효과 무시.
- Soul Sand, Cobweb 등 지형 감속을 무시.
- Lava 안에서의 이동을 물속 이동과 같은 수준으로 취급.
- Lava와 관련된 이동/피해 처리 세부는 이 Gold Boots 효과의 일부로 구현하며, 정확한 수치와 판정은 Mod 단계에서 확정.

## Diamond / 다이아몬드
Helmet [LOCKED]
- Headshot/projectile damage -35%.
- Explosion damage -25%.

Chestplate [LOCKED]
- 피격마다 4초간 받는 피해 -6%.
- 최대 4중첩 = -24%.
- 4초간 미피격 시 초기화.

Leggings [LOCKED]
- 모든 knockback 효과 무효.
- knockback resistance 100%.

Boots [LOCKED]
- 낙하 피해의 큰 부분을 부츠 내구도 손실로 전환.
- 출발점 예시: 낙하 피해 약 70% 감소.

## Netherite / 네더라이트
Helmet [LOCKED]
- 불타고 있는 적에게 가하는 공격 피해 증가.

Chestplate [LOCKED]
- 화염 및 용암 피해 완전 면역.
- 원래 화염 피해가 발생했을 상황에서는 오히려 체력 회복.
- 모든 종류의 공격에 일정 확률로 target에 화염 부여 가능.
- Helmet과 시너지.

Leggings [LOCKED]
- 용암 내부 이동을 물과 사실상 동일한 수준으로 변경.
- 수평 이동 + 상승/하강 제어 포함.

Boots [LOCKED]
- 뜨거운 걸음.
- Lava surface에 임시 Obsidian 생성.
- 일정 시간 후 원래 lava로 복원.
- 별도 B안은 폐기.
- 향후 enchantment로 이동할 가능성은 열어둠.

## Iron / 철
Helmet [LOCKED]
- 공격자를 바라보고 있을 때 근접 피해 추가 감소.
- 출발점 예시: 15%.

Chestplate [LOCKED]
- 근접 피격 시 10% 확률로 받은 피해 완전 무효.

Leggings [LOCKED]
- knockback resistance +30%.
- 원거리 피해 -15%.

Boots [LOCKED]
- 3블록 이상 높이에서 적 위로 정확히 착지 시
  자신의 fall damage를 적에게 전이.
- Mace impact 연출 활용.

## Redstone / 레드스톤
Helmet [LOCKED]
- 피해를 받으면 다음 근접 공격 1회가 즉시 fully-charged attack 상태.
- 약 4초 cooldown.

Chestplate [LOCKED]
- HP가 일정 비율 아래로 내려가면 자동 오버클럭.
- 약 4초간 movement / attack / mining speed 크게 상승.
- 긴 cooldown.

Leggings [LOCKED]
- 적 처치 시 attack speed + movement speed 상승.
- 재처치 시 duration refresh.
- 최대 stack 존재.

Boots [LOCKED]
- 지상에서 특수 입력으로 강한 수직 점프.
- 짧은 cooldown.
- 입력키는 Mod 단계에서 결정.

## Titanium / 티타늄
Helmet [LOCKED]
- Elytra/Riptide/급가속 등 고속 이동 중 collision damage 크게 감소.
- 약간의 일반 방어 보너스.

Chestplate [LOCKED]
- Bow aim, food use, shield use 등 item use 중 이동속도 감소를 크게 완화.

Leggings [LOCKED]
- Sprint 효율 증가.
- 기본 이동속도 증가.
- 공중에서 jump 입력 시 전방 dash-leap.

Boots [LOCKED]
- 특수 입력으로 바라보는 방향에 짧고 빠른 dash.
- 지상/공중 사용 가능.
- 짧은 cooldown.

## Tungsten / 텅스텐
Helmet [LOCKED]
- Sprint 상태로 entity와 정면 충돌 시 물리 피해 + 큰 knockback + 짧은 stagger.
- 자신의 sprint는 유지.

Chestplate [LOCKED]
- 작은 단일 피해에 매우 강함.
- threshold 이하 공격에 큰 추가 감소.

Leggings [LOCKED]
- 일정 시간 sprint한 뒤 첫 melee attack에
  운동량 비례 추가 피해 + 큰 knockback.

Boots [LOCKED]
- Sneak 후 짧은 준비시간으로 지면 고정.
- 고정 중:
  - knockback 거의 완전 무효
  - explosion/water current/bubble column/piston 이동 저항
  - 받는 피해 극단적으로 감소
  - 이동/점프 불가
- sneak 해제 시 즉시 종료.

## Mithril / 미스릴
Helmet [LOCKED]
- 해로운 status effect 지속시간 크게 단축.

Chestplate [LOCKED]
- potion/magic/sonic/custom magical damage 계열을 크게 감소.

Leggings [LOCKED]
- 일정 시간형 positive buff가 종료되면
  약화된 잔향 버전을 잠시 유지.

Boots [LOCKED]
- 착지 시 조건/cooldown에 따라 바닥에 짧은 Mithril magic circle 생성.
- circle 안에서:
  - 자신/아군 skill cooldown recovery 증가
  - positive magic effect 유지 보조
  - 적의 magic/special effect 약화.

## Excluded from coating
- Luminite: coating 설계에서 폐기.
- Aquamarine: coating 제외.
- Adamantium: coating 제외, 광물 컨셉은 유지.
- Etherium: coating 제외.
