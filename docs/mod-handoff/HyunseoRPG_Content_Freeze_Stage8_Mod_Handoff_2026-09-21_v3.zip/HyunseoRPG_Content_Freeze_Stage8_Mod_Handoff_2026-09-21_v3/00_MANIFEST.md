# HyunseoRPG Content Freeze Stage 8 → Mod Handoff Package v3

기준일: 2026-09-21
리비전: v3 correction freeze

## 목적

이 패키지는 Paper 플러그인 구조개편이 종료된 뒤, Mod Stage 1에 들어가기 전에
현재까지 확정된 추가 설계를 구현과 분리하여 보존하는 설계 원본이다.

이 패키지는 구현 코드가 아니다.
Mod 이식 시에는 이 문서를 Source of Truth로 삼되,
Fabric/NeoForge/MC 버전/API에 따른 기술 구현은 Mod Stage에서 별도로 결정한다.

## 현재 위치

- Refactor Stage 1-7: Paper Vanilla-Native 구조개편 및 최종 감사/정리
- Content Freeze Stage 8: 현재 설계 동결 및 패키징
- Mod Stage 1+: 이후 실제 모드 재조립

## Mod Stage 1 진입 전 종료 조건

1. 전체 구조 감사 종료
2. Paper 플러그인 구조 동결
3. GitHub repository / branch / PR 정리 및 종료
4. 본 Content Freeze 패키지 보존
5. 이후 Mod Stage 1 진입

## 상태 표기

- LOCKED: 설계 방향 확정
- BALANCE-DEFERRED: 기능은 확정, 수치만 추후 밸런싱
- IMPLEMENTATION-DEFERRED: 기능은 확정, 구현 방식은 모드 단계에서 결정
- CANDIDATE: 보존하지만 미확정
- EXCLUDED-FROM-COATING: 광물 후보는 유지 가능하나 코팅에서는 제외

## v3 정정 사항

- v2에 잘못 포함된 `수리 키트`, `열 차폐판` 항목 제거.
- Iron Leggings coating을 `knockback resistance +30% / ranged damage -15%`로 복구.
- Gold Boots coating의 지형 감속 무시 및 Lava 이동 관련 확정 의도를 복구.
- 이 v3가 Mod Stage 진입 시 설계 기준본이며 v2는 역사 기록으로만 취급한다.
