# 3. Coating System Rules

## 정체성

Coating은 새로운 장비 티어가 아니다.

- Gear Tier = 장비 본체의 기본 성능/정체성
- Enhancement = 수치 성장
- Coating = 기능 성장

세 축은 독립적이며 필수 선행조건이 아니다.

## 기본 문법

Smithing Table 문법을 확장한다.

Template + Equipment + Material → 기존 Equipment에 Coating 기능 추가

형판 종류 자체의 구체 목록/기능 매핑은 후속 설계로 넘긴다.

## 효과 결정 규칙

> Coating Material × Equipment Type → 기능

광물은 공통된 성격을 갖고,
장비 부위가 그 성격의 발현 방식을 결정한다.

## 중첩

- 서로 다른 coating을 한 장비에 여러 개 누적 가능.
- 동일 광물 반복 coating은 기본적으로 금지.
- 논리적으로 충돌하는 조합만 개별 incompatibility 처리.
- 전체 coating slot 제한은 기본적으로 두지 않는 방향.

## 형판 경제

- 기능형 template은 사용 시 소모.
- 손쉬운 무제한 복제는 제거 또는 강하게 제한.
- 획득률/구조물 배치/제작 난이도 재조정 필요.
- 장식용 vanilla trim의 자유도와 기능형 coating 경제는 분리 가능.

## 사실상 티어

광물 자체 희귀도와 획득 시점 때문에 coating에도 자연스럽게 power tier가 생길 수 있음.
현재는 강제 평탄화하지 않음.
전체 matrix 종료 후 power curve만 별도 검토.

## 코팅 제외 광물

- Aquamarine
- Adamantium
- Etherium
- Luminite는 coating 설계에서 폐기

Adamantium 광물 컨셉:
> 절대 부서지지 않는 물질.
