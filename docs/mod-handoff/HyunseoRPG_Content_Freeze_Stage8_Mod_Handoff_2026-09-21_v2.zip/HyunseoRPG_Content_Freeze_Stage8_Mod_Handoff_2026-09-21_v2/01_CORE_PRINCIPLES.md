# 1. Core Design Principles

## North Star

> 바닐라를 대체하지 않는다. 바닐라의 끝을 확장한다.

HyunseoRPG는 별도 RPG 게임을 Minecraft 위에 얹는 구조가 아니라,
Minecraft의 행동·자원·탐험·제작·장비를 그대로 출발점으로 확장한다.

## 장비 성장

무기:
- T1: Vanilla
- T2: Elemental
- T3: Special
- T4: Endgame

갑옷:
- T1: Vanilla armor family 전체
- T2: 큰 갭을 둔 Special armor
- T3: Endgame armor

갑옷은 강화 + 코팅 다중 적용이 가능하므로 무기보다 티어 수를 적게 두고
티어 간 간격을 크게 둔다.

강화와 코팅은 다음 티어 진입의 필수 선행조건으로 취급하지 않는다.
선택적 성장축이다.

## 제작/탐험

- 코인 경제 없음.
- 별도 채광 성장 시스템 없음.
- 바닐라 제작대/화로/용광로/모루/대장장이 작업대 적극 활용.
- 신규 광물은 범용 제작 재료.
- 합금 중간재 시스템은 만들지 않음.
- 탐험은 기존 월드/구조물을 대체하지 않음.
- 신규 콘텐츠는 바닐라 행동의 의미를 확장.

## Custom Item Identity

장기 방향:
- 서버/게임 로직 ID: component/PDC 또는 모드의 정식 data component
- 외형: ItemModel/모드 모델 시스템
- Lore는 표시 전용이며 실제 상태의 Source of Truth가 아님.
