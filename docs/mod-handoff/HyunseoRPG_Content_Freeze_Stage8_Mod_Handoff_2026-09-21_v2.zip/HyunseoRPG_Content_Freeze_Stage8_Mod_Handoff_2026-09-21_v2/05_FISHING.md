# 5. Fishing System

## Core [LOCKED]
- Vanilla cast/wait 유지.
- bite 시 fishing minigame 시작.
- 좌우 대칭 linear spectrum bar.
- marker가 좌우 이동.
- 양 끝은 failure, 정확한 중앙은 success.
- 중간 cell 판정은 BALANCE-DEFERRED.
- Fish는 ItemStack으로 획득.
- species/type, 약 5단계 quality, length 보유.
- 개념적 가치 = length × species × grade.

## Fishing Rod Module UI [LOCKED]
- Right-click rod = normal fishing/cast.
- Left-click rod = 1-row custom module UI.
- Fixed slots: Reel / Crankbait / Minnow.
- module은 넣기/빼기/교체 가능.
- 실제 ItemStack state를 보존.

## Reel [LOCKED]
- 5 grades.
- durability 존재.
- discovery/access scope 확대.

## Crankbait [LOCKED]
- 5 grades.
- durability 존재.
- 이미 접근 가능한 candidate pool 안에서 상위 fish 확률 증가.
- 접근 불가능 fish는 해금하지 않음.

## Minnow [LOCKED]
- 5 grades.
- durability 존재.
- actual capture permission/gate.
- Reel로 발견 가능해도 요구 grade 미달이면 catch 불가.

## Material direction [DEFERRED]
- Reel / Crankbait / Minnow exact recipe/material은 광물/recipe 단계에서 확정.
