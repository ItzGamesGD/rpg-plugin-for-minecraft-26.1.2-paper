# 7. Mod Stage Handoff

## Mod Stage에서 결정할 기술 항목

- loader: Fabric / NeoForge 등
- Minecraft target version
- component/data APIs
- rendering/model pipeline
- custom keybinds
- custom GUI implementation
- dynamic lighting implementation
- collision/physics hooks
- damage type definitions
- networking/sync
- exact balance numbers
- exact recipes
- ore world-generation parameters
- template acquisition/drop locations and rates

## Mod Stage 1 진입 조건

- Paper 전체 구조 감사 완료
- Paper plugin 구조 동결
- live-unverified 항목 별도 목록화
- repository 정리
- stale branch/PR 정리
- authoritative final Paper head/tag 결정
- 필요한 source archive/notes 보존
- 본 Content Freeze package 보존

## Mod 개발 원칙

Paper 코드를 그대로 기계적으로 번역하지 않는다.

1. Paper 구현이 표현하던 gameplay contract를 읽는다.
2. Mod engine에서 가장 자연스러운 primitive로 다시 구현한다.
3. 기존 vanilla behavior를 삭제하지 않는다.
4. content 단위는 module화한다.
5. 공통 runtime/registry/component는 foundation에 둔다.
6. weapon/equipment/fishing/mining/alchemy 등은 그 위에 확장한다.

## Freeze rule

이 패키지 이후 Paper branch에서는
"모드에서 구현할 신규 콘텐츠"를 계속 증식시키지 않는다.

Paper는 구조 감사 / cleanup / regression / archival prototype 역할로 닫는다.
새 콘텐츠 개발은 Mod Stage에서 재개한다.
