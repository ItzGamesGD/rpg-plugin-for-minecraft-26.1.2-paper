# 6. Materials / Mining Handoff

## Mining philosophy [LOCKED]

- 별도 mining RPG system 없음.
- mining level/progression 없음.
- ore quality 없음.
- mining GUI 없음.
- 바닐라 채광 유지.
- 신규 광물은 equipment/utility/coating crafting ingredient.

## Material-design procedure [LOCKED]

1. 각 장비의 현실적 구성요소를 분해.
2. 구성요소가 요구하는 물성/기능을 적음.
3. 비슷한 요구를 material family로 압축.
4. 직관적 real material이 있으면 사용.
5. 판타지적/복합적이면 custom material 창작.
6. 각 광물을 하나의 전용 아이템 열쇠로 만들지 않음.
7. 여러 recipe에서 유기적으로 재사용.
8. Alloy intermediate system은 만들지 않음.

## Current custom material concepts

### Titanium [ACTIVE]
경량 고강도 구조재. mobility/utility에 폭넓게 사용.

### Tungsten [ACTIVE]
질량/내마모/고하중 소재. Drill 및 중장갑 계열.

### Mithril [ACTIVE]
마법 안정화/조작/유지 계열.

### Adamantium [CONCEPT LOCKED, COATING EXCLUDED]
"절대 부서지지 않는 물질."
향후 최상위 재료/장비에서 사용 가능.

### Aquamarine [CANDIDATE, COATING EXCLUDED]
water/pressure 계열 후보.

### Etherium [CANDIDATE, COATING EXCLUDED]
spatial/phase 계열 후보.

### Luminite
coating 후보에서는 폐기.
광물 자체 유지 여부는 미정.

## Vanilla materials actively reused

Copper, Iron, Diamond, Redstone, Emerald, Lapis Lazuli,
Amethyst, Quartz, Netherite, Leather, Wool, Wood, Stone,
Glass, Gunpowder, Paper, Prismarine, Dyes, Coal/Coal Block,
elemental materials such as 불꽃의 심장.

## World generation [DEFERRED]

광물 목록과 예상 consumption을 확정한 뒤 결정:
- dimension
- Y distribution
- vein size
- rarity
- cluster/vein style
- expected material consumption
- retro-generation policy
